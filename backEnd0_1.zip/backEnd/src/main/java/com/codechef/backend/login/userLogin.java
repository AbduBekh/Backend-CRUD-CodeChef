package com.codechef.backend.login;

import javax.persistence.*;

@Entity
@Table
public class userLogin {
    @Id
    @SequenceGenerator(
            name = "userLogin_sequence",
            sequenceName = "userLogin_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "userLogin_sequence"
    )
    private String ID;
    private String USERNAME;
    private String  PASSWORD;
    private String USERTYPE;

    // Constructors

    // no arg constructor
    public userLogin() {
    }
    // Constructor without Id
    public userLogin(String USERNAME, String PASSWORD, String USERTYPE) {
        this.USERNAME = USERNAME;
        this.PASSWORD = PASSWORD;
        this.USERTYPE = USERTYPE;
    }
    // Constructor with everything

    public userLogin(String ID, String USERNAME, String PASSWORD, String USERTYPE) {
        this.ID = ID;
        this.USERNAME = USERNAME;
        this.PASSWORD = PASSWORD;
        this.USERTYPE = USERTYPE;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getUSERNAME() {
        return USERNAME;
    }

    public void setUSERNAME(String USERNAME) {
        this.USERNAME = USERNAME;
    }

    public String getPASSWORD() {
        return PASSWORD;
    }

    public void setPASSWORD(String PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public String getUSERTYPE() {
        return USERTYPE;
    }

    public void setUSERTYPE(String USERTYPE) {
        this.USERTYPE = USERTYPE;
    }

    @Override
    public String toString() {
        return "userLogin{" +
                "ID='" + ID + '\'' +
                ", USERNAME='" + USERNAME + '\'' +
                ", PASSWORD='" + PASSWORD + '\'' +
                ", USERTYPE='" + USERTYPE + '\'' +
                '}';
    }
}
