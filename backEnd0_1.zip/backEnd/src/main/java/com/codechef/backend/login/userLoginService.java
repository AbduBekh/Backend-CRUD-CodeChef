package com.codechef.backend.login;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class userLoginService {
    @Autowired
    private final userLoginRepository userloginRepository;

    @Autowired
    public userLoginService(userLoginRepository userloginRepository) {
        this.userloginRepository = userloginRepository;
    }

    public List<userLogin> getuserLogin(){
        return userloginRepository.findAll();
    }
}