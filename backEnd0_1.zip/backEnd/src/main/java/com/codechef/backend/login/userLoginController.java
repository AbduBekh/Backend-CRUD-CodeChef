package com.codechef.backend.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path= "api/v1/userLogin")
public class userLoginController {
    @Autowired
    private final userLoginService userloginService;

    @Autowired
    public userLoginController(userLoginService userloginService) {
        this.userloginService = userloginService;
    }


    @GetMapping
    public List<userLogin> getuserLogin(){
        return userloginService.getuserLogin();
    }
}